# JSXGraph AIR for VS Code

**Artificial Intelligence Renderer – powered by JSXGraph**

Create dynamic geometry with AI assistance, right from your editor. JSXGraph AIR
for Visual Studio Code turns a browser tab into a live preview for your JSXGraph
constructions: let GitHub Copilot (or any AI assistant in VS Code) write the code
in `construction.js` — every save instantly updates the rendered construction.
Additional libraries such as MathJax or custom CSS can be added via `header.js`,
guarded by a configurable allowlist. When you're done, export your work as a
single self-contained HTML file or copy it straight to the clipboard.

## Package contents

| File                      | Purpose                                                        |
| ------------------------- | -------------------------------------------------------------- |
| `JSXGraph-AIR-VSCode.html`| The live preview page (open in your browser)                   |
| `server.js`               | Local bridge server: watches `construction.js` and `header.js` |
| `package.json`            | Node.js package definition (dependency: `ws`)                  |
| `.vscode/tasks.json`      | Optional VS Code task that starts the server automatically     |

`construction.js` and `header.js` are created automatically with a starter
template the first time the server runs.

## Requirements

- **Node.js** (LTS version recommended) — runs the local bridge server;
  includes `npm`. Download from <https://nodejs.org>
- **Visual Studio Code** — download from <https://code.visualstudio.com>
- **GitHub Copilot extension** (optional, recommended) — requires a GitHub
  account with an active Copilot subscription. Any other editor-based AI
  assistant works as well.
- **A modern web browser** (Chrome, Firefox, Safari, Edge)
- **Internet connection** — for loading the JSXGraph library from CDN and for
  Copilot; the bridge server itself runs entirely locally.

## Installation

1. **Unzip** this package into a folder of your choice
   (avoid spaces in the folder name if possible).

2. **Open the folder in VS Code**
   (*File → Open Folder…*).

3. **Install the dependency** — in the VS Code terminal
   (*Terminal → New Terminal*), run once:

   ```
   npm install
   ```

4. **Start the bridge server:**

   ```
   npm start
   ```

   You should see:

   ```
   AIR VS Code Bridge is running.
     WebSocket:       ws://localhost:8787
   ```

   Alternatively, allow the included VS Code task when prompted — it starts
   the server automatically every time the folder is opened.

5. **Open the preview page** — open `JSXGraph-AIR-VSCode.html` in your
   browser (double-click, or use an extension such as *Live Server*).
   The page connects to `ws://localhost:8787` automatically. If it does not,
   click the plug icon in the status bar, check the address, and press
   **Connect**.

6. **Let Copilot draw** — open `construction.js` in VS Code and ask Copilot
   Chat, for example:

   > "Add a red circle of radius 3 around the origin in construction.js"

   Saving the file updates the preview instantly.

   **Note:** the preview page provides a constant called `BOARD` (the id of
   the div JSXGraph renders into). Constructions should call
   `JXG.JSXGraph.initBoard(BOARD, {...})` instead of hardcoding an id string.

7. **Optional: customize the page head** — edit `header.js` to add external
   libraries (e.g. MathJax) or custom CSS. Which element categories are
   allowed can be controlled in the preview page under **Settings** (gear
   icon).

A step-by-step guide is also built into the preview page itself (❓ icon in
the status bar).

## Security model

- `construction.js` is checked in the browser against a fixed blocklist
  (no `<script>`, no `eval`, no network/storage access).
- `header.js` is checked against a structured allowlist (only
  `<script src="https://…">`, `<link rel="stylesheet">`, `<meta>`, `<style>`),
  each category toggleable in the Settings panel.

## Troubleshooting

- **`command not found: npm`** — Node.js is not installed (or not on your
  PATH). Install it from <https://nodejs.org>, then reopen the terminal.
- **`Cannot find module 'ws'`** — `npm install` has not been run in this
  folder yet (step 3).
- **"Connection failed" in the preview** — the bridge server is not running
  (step 4), or a different port is used. To use another port:
  `node server.js construction.js header.js 9000` and enter
  `ws://localhost:9000` in the Connection panel.

---

JSXGraph AIR for VS Code · Copyright 2026 Carsten Miller · <https://jsxgraph.org>
